-- Databricks notebook source
SELECT current_catalog()

-- COMMAND ----------

SELECT * FROM demo_catalog.demo_schema.circuits

-- COMMAND ----------

SHOW CATALOGS

-- COMMAND ----------

USE CATALOG demo_catalog;
USE SCHEMA DEMO_SCHEMA

-- COMMAND ----------

SELECT * FROM circuits

-- COMMAND ----------

SHOW TABLES

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(spark.sql("SHOW TABLES IN demo_schema"))

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(spark.table('demo_catalog.demo_schema.circuits'))
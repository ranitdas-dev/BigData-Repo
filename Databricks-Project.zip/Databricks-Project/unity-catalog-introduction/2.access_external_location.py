# Databricks notebook source
display(dbutils.fs.ls('abfss://demo@databricksprojucextdl.dfs.core.windows.net/'))
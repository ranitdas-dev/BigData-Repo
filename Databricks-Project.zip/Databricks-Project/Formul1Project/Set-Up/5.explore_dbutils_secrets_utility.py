# Databricks notebook source
dbutils.secrets.help() 

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.list(scope="Databricks-Project-Scope")

# COMMAND ----------

dbutils.secrets.get(scope="Databricks-Project-Scope", key="formula1carracingdl-account-key")

# COMMAND ----------


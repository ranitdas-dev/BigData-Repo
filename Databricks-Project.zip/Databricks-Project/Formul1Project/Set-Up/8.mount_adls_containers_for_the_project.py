# Databricks notebook source
# MAGIC %md
# MAGIC #### Mount Azure data lake containers for the project
# MAGIC

# COMMAND ----------

def mount_adls_Gen2(storageAccountName, containerName):
    #Get secrets from Key Vault

    client_Id = dbutils.secrets.get(scope="Databricks-Project-Scope", key="DatabricksProject-App-ClientId")
    tenant_Id = dbutils.secrets.get(scope="Databricks-Project-Scope", key="DatabricksProject-App-TenantId")
    client_Secret = dbutils.secrets.get(scope="Databricks-Project-Scope", key="DatabricksProject-App-ClientSecret")

    #Set spark Configurations
    configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": client_Id,
          "fs.azure.account.oauth2.client.secret": client_Secret,
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_Id}/oauth2/token"}
    
    if any(mount.mountPoint == f"/mnt/{storageAccountName}/{containerName}" for mount in dbutils.fs.mounts()):
        dbutils.fs.unmount(f"/mnt/{storageAccountName}/{containerName}")
    
    #Mount storage Account
    dbutils.fs.mount(
        source = f"abfss://{containerName}@{storageAccountName}.dfs.core.windows.net/",
        mount_point = f"/mnt/{storageAccountName}/{containerName}",
        extra_configs = configs)
    
    display(dbutils.fs.mounts())

# COMMAND ----------

mount_adls_Gen2("formula1carracingdl", "bronze")

# COMMAND ----------

mount_adls_Gen2("formula1carracingdl", "silver")

# COMMAND ----------

mount_adls_Gen2("formula1carracingdl", "gold")

# COMMAND ----------

mount_adls_Gen2("formula1carracingdl", "ingestfull")
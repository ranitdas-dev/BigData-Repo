# Databricks notebook source
display(dbutils.fs.ls("dbfs:/FileStore/demo-data/"))

# COMMAND ----------

display(dbutils.fs.ls("/"))

# COMMAND ----------

display(spark.read.csv("/FileStore/demo-data/"))
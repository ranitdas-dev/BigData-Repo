# Databricks notebook source
# MAGIC %md
# MAGIC #### Access azure data lake using access keys
# MAGIC 1. List files from demo container
# MAGIC 1. Read data from circuits.csv file

# COMMAND ----------

formula1carracingdl_Account_Key = dbutils.secrets.get(scope="Databricks-Project-Scope", key="formula1carracingdl-account-key")

# COMMAND ----------

spark.conf.set("fs.azure.account.key.formula1carracingdl.dfs.core.windows.net",formula1carracingdl_Account_Key)

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1carracingdl.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1carracingdl.dfs.core.windows.net/circuits.csv"))
# Databricks notebook source
# MAGIC %md
# MAGIC #### Access azure data lake using Service Principal
# MAGIC 1. Register Service Principal
# MAGIC 1. Generate secret/password for the application
# MAGIC 1. Create the file system utility mount to moun the storage
# MAGIC 1. List files from demo container
# MAGIC 1. Read data from circuits.csv file

# COMMAND ----------

client_Id = dbutils.secrets.get(scope="Databricks-Project-Scope", key="DatabricksProject-App-ClientId")
tenant_Id = dbutils.secrets.get(scope="Databricks-Project-Scope", key="DatabricksProject-App-TenantId")
client_Secret = dbutils.secrets.get(scope="Databricks-Project-Scope", key="DatabricksProject-App-ClientSecret")

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": client_Id,
          "fs.azure.account.oauth2.client.secret": client_Secret,
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_Id}/oauth2/token"}

# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://demo@formula1carracingdl.dfs.core.windows.net/",
  mount_point = "/mnt/formula1carracingdl/demo",
  extra_configs = configs)

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1carracingdl/demo"))

# COMMAND ----------

display(spark.read.csv("/mnt/formula1carracingdl/demo/circuits.csv"))

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

dbutils.fs.help()

# COMMAND ----------

dbutils.fs.unmount("/mnt/formula1carracingdl/demo")
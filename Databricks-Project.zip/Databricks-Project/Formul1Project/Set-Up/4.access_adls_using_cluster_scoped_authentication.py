# Databricks notebook source
# MAGIC %md
# MAGIC #### Access azure data lake using cluster scope authentication
# MAGIC 1. List files from demo container
# MAGIC 1. Read data from circuits.csv file

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1carracingdl.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1carracingdl.dfs.core.windows.net/circuits.csv"))
# Databricks notebook source
# MAGIC %md
# MAGIC #### Access azure data lake using Service Principal
# MAGIC 1. Register Service Principal
# MAGIC 1. Generate secret/password for the application
# MAGIC 1. List files from demo container
# MAGIC 1. Read data from circuits.csv file

# COMMAND ----------

client_Id = dbutils.secrets.get(scope="Databricks-Project-Scope", key="DatabricksProject-App-ClientId")
tenant_Id = dbutils.secrets.get(scope="Databricks-Project-Scope", key="DatabricksProject-App-TenantId")
client_Secret = dbutils.secrets.get(scope="Databricks-Project-Scope", key="DatabricksProject-App-ClientSecret")

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.formula1carracingdl.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.formula1carracingdl.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.formula1carracingdl.dfs.core.windows.net", client_Id)
spark.conf.set("fs.azure.account.oauth2.client.secret.formula1carracingdl.dfs.core.windows.net", client_Secret)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.formula1carracingdl.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_Id}/oauth2/token")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1carracingdl.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1carracingdl.dfs.core.windows.net/circuits.csv"))
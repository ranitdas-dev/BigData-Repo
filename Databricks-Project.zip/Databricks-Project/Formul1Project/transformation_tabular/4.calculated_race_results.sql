-- Databricks notebook source
--The destination table hive_metastore.f1_gold.calculated_race_results is used in analysis folder.

-- COMMAND ----------

USE hive_metastore.f1_gold;

-- COMMAND ----------

-- DBTITLE 1,s
CREATE TABLE IF NOT EXISTS hive_metastore.f1_gold.calculated_race_results
USING PARQUET
AS
SELECT ra.race_year  
  ,c.name AS team_name
  ,d.name AS driver_Name
  , r.position
  ,r.points
  , 11 - cast(r.position AS INT) AS Calculated_Points 
FROM hive_metastore.f1_silver.results r
INNER JOIN hive_metastore.f1_silver.drivers d ON d.driver_id = r.driver_Id
INNER JOIN hive_metastore.f1_silver.constructors c ON c.constructor_Id = r.constructor_Id
INNER JOIN hive_metastore.f1_silver.races ra ON ra.race_Id = r.race_Id
WHERE r.position <= 10
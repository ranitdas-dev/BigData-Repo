-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS hive_metastore.f1_gold
LOCATION "/mnt/formula1carracingdl/ingestfull/gold/"
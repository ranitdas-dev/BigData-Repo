-- Databricks notebook source
-- MAGIC %python
-- MAGIC
-- MAGIC html = """<h1> Report on Dominant Formula1 Teams </h1>"""
-- MAGIC displayHTML(html)

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW v_dominant_teams
AS
select 
team_name
,count(1) AS total_races
,sum(Calculated_Points) as total_points
,avg(Calculated_Points) as avg_points
,RANK() OVER (ORDER BY avg(Calculated_Points) DESC) as team_rank
 from hive_metastore.f1_gold.calculated_race_results
 --where race_year between 2000 and 2020
 group by team_name
 HAVING count(1) > 100
 order by avg_points desc

-- COMMAND ----------

select 
 race_year
,team_name
,count(1) AS total_races
,sum(Calculated_Points) as total_points
,avg(Calculated_Points) as avg_points
 from hive_metastore.f1_gold.calculated_race_results
 WHERE team_name in (select team_name from v_dominant_teams where team_rank <= 5)
 group by team_name, race_year
 order by race_year, avg_points desc
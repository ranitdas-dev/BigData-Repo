-- Databricks notebook source
select 
 team_name
,count(1) AS total_races
,sum(Calculated_Points) as total_points
,avg(Calculated_Points) as avg_points
 from hive_metastore.f1_gold.calculated_race_results
 --where race_year between 2000 and 2020
 group by team_name
 HAVING count(1) > 100
 order by avg_points desc
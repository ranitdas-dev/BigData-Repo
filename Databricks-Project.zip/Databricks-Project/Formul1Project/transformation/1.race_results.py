# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

drivers_df = spark.read.parquet(f"{silver_folder_path2}/drivers") \
                .withColumnRenamed("number", "driver_number") \
                .withColumnRenamed("name", "driver_name") \
                .withColumnRenamed("nationality", "driver_nationality")

# COMMAND ----------

constructors_df = spark.read.format("parquet").load(f"{silver_folder_path2}/constructors")\
                    .withColumnRenamed("name", "team")

# COMMAND ----------

races_df = spark.read.parquet(f"{silver_folder_path2}/races") \
                .withColumnRenamed("name", "race_name") \
                .withColumnRenamed("race_timestamp", "race_date")

# COMMAND ----------

circuits_df = spark.read.parquet(f"{silver_folder_path2}/circuits") \
                .withColumnRenamed("location", "circuit_location")

# COMMAND ----------

results_df = spark.read.parquet(f"{silver_folder_path2}/results") \
                .withColumnRenamed("time", "race_time")

# COMMAND ----------

race_results_df = results_df.join(races_df, results_df.race_id == races_df.race_id) \
                            .join(circuits_df, circuits_df.circuit_id == races_df.circuit_id, "inner") \
                            .join(drivers_df, results_df.driver_id == drivers_df.driver_id) \
                            .join(constructors_df, results_df.constructor_id == constructors_df.constructor_id, "inner") \
                            .select(  races_df.race_year \
                                    , races_df.race_date \
                                    , races_df.race_name \
                                    , circuits_df.circuit_location \
                                    , drivers_df.driver_name \
                                    , drivers_df.driver_number \
                                    , drivers_df.driver_nationality \
                                    , constructors_df.team \
                                    , results_df.grid \
                                    , results_df.fastest_lap \
                                    , results_df.race_time \
                                    , results_df.points \
                                    , results_df.position)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit
race_results_final_df = race_results_df \
                        .withColumn("ingestion_date", current_timestamp()) \
                        .withColumn("stage", lit("gold"))

# COMMAND ----------

race_results_final_df.write.mode("overwrite").parquet(f"{gold_folder_path2}/race_results")
# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

race_results_df = spark.read.parquet(f"{gold_folder_path2}/race_results")

# COMMAND ----------

from pyspark.sql.functions import sum, when, count, col
driver_standings_df = race_results_df \
                        .groupBy('race_year', 'driver_name', 'driver_nationality', 'team') \
                        .agg(sum('points').alias('total_points') \
                            ,count(when(col('position') == 1, True)).alias('wins'))

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import rank

window = Window.partitionBy('race_year').orderBy(col('total_points').desc(), col('wins').desc())
driver_standings_df_final = driver_standings_df.withColumn('rank', rank().over(window))

# COMMAND ----------

driver_standings_df_final.write.mode("overwrite").parquet(f"{gold_folder_path2}/driver_standings")
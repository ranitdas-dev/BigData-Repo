-- Databricks notebook source
DROP DATABASE IF EXISTS f1_silver CASCADE;

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS hive_metastore.f1_silver_Incremental
LOCATION "/mnt/formula1carracingdl/silver"

-- COMMAND ----------

DROP DATABASE IF EXISTS f1_gold CASCADE;

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS hive_metastore.f1_gold_Incremental
LOCATION "/mnt/formula1carracingdl/gold"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(dbutils.fs.mounts())
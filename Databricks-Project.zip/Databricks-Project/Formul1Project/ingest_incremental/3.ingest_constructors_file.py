# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest constructors.json file

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

dbutils.widgets.text(name="p_data_source", defaultValue="Ergest API")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text(name="p_file_date", defaultValue="2021-03-21")
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1 - Read the JSON file using spark dataframe reader.

# COMMAND ----------

constructors_schema = "constructorId INT, constructorRef STRING, name STRING, nationality STRING, url STRING"

# COMMAND ----------

constructors_df = spark.read.format("json").schema(constructors_schema).load(f"{bronze_folder_path}/{v_file_date}/constructors.json")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2 - Drop unwanted column from the dataframe

# COMMAND ----------

constructors_dropped_df = constructors_df.drop("url")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3 - Rename Column and Add ingestion_date to dataframe

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit
constructors_final_df = constructors_dropped_df \
                        .withColumnsRenamed({"constructorId": "constructor_id", "constructorRef": "constructor_ref"}) \
                        .withColumn("ingestion_date", current_timestamp()) \
                        .withColumn("source", lit("silver")) \
                        .withColumn("data_source", lit(v_data_source)) \
                        .withColumn("file_date", lit(v_file_date))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 5 - Write data to parquet

# COMMAND ----------

constructors_final_df.write.mode("overwrite").format("parquet").saveAsTable("hive_metastore.f1_silver_incremental.constructors")

# COMMAND ----------

dbutils.notebook.exit("OK")
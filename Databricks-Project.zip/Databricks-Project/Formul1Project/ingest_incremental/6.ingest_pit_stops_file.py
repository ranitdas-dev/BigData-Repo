# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest pit_stops.json file

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text(name="p_data_source", defaultValue="Ergest API")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text(name="p_file_date", defaultValue="2021-03-28")
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1 -  Read the JSON file using the spark dataframe reader API

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# COMMAND ----------

pit_stops_schema = StructType(fields=[StructField("driverId", IntegerType(), True),
                                    StructField("duration", StringType(), True),
                                    StructField("lap", IntegerType(), True),
                                    StructField("milliseconds", IntegerType(), True),
                                    StructField("raceId", IntegerType(), True),
                                    StructField("stop", IntegerType(), True),
                                    StructField("time", StringType(), True)])

# COMMAND ----------

pit_stops_df = spark.read \
                .schema(pit_stops_schema) \
                .json(f"{bronze_folder_path}/{v_file_date}/pit_stops.json", multiLine=True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2 - Rename columns and add new columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit
pit_stops_final_df = pit_stops_df \
                          .withColumnsRenamed({"driverId": "driver_id", "raceId": "race_id"}) \
                          .withColumns({"ingestion_date" : current_timestamp(), "stage" : lit("silver")}) \
                          .withColumn("data_source", lit(v_data_source)) \
                          .withColumn("file_date", lit(v_file_date))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3 - Write output to parquet format

# COMMAND ----------

#pit_stops_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_silver.pit_stops")
overwrite_partition(pit_stops_final_df, "hive_metastore", "f1_silver_incremental", "pit_stops", "race_id")

# COMMAND ----------

dbutils.notebook.exit("OK")

# COMMAND ----------

# MAGIC %sql
# MAGIC select race_id, count(*) from hive_metastore.f1_silver_incremental.pit_stops
# MAGIC group by race_id
# MAGIC order by race_id
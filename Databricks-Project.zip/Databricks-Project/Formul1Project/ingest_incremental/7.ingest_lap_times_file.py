# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest lap_times csv files

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text(name="p_data_source", defaultValue="Ergest API")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text(name="p_file_date", defaultValue="2021-03-28")
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1 -  Read multiple CSV files using the spark dataframe reader API

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# COMMAND ----------

lap_times_schema = StructType(fields=[StructField("raceId", IntegerType(), True),
                                        StructField("driverId", IntegerType(), True),
                                        StructField("lap", IntegerType(), True),
                                        StructField("position", IntegerType(), True),
                                        StructField("time", StringType(), True),
                                        StructField("milliseconds", IntegerType(), True)])

# COMMAND ----------

lap_times_df = spark.read \
                .schema(lap_times_schema) \
                .csv(f"{bronze_folder_path}/{v_file_date}/lap_times/")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2 - Rename columns and add new columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit
lap_times_final_df = lap_times_df \
                          .withColumnsRenamed({"driverId": "driver_id", "raceId": "race_id"}) \
                          .withColumns({"ingestion_date" : current_timestamp(), "stage" : lit("silver")}) \
                          .withColumn("data_source", lit(v_data_source)) \
                          .withColumn("file_date", lit(v_file_date))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3 - Write output to parquet format

# COMMAND ----------

overwrite_partition(lap_times_final_df, "hive_metastore", "f1_silver_incremental", "lap_times", "race_id")

# COMMAND ----------

dbutils.notebook.exit("OK")

# COMMAND ----------

# MAGIC %sql
# MAGIC select race_id, count(*) from hive_metastore.f1_silver_incremental.lap_times
# MAGIC group by race_id
# MAGIC order by race_id
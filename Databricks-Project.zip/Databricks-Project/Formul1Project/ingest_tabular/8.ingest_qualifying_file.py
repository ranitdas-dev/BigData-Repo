# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest qualifying json files

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

dbutils.widgets.text(name="p_data_source", defaultValue="Ergest API")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1 -  Read multiple JSON files using the spark dataframe reader API

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# COMMAND ----------

qualifying_schema = StructType(fields=[StructField("raceId", IntegerType(), True),
                                       StructField("driverId", IntegerType(), True),
                                       StructField("constructorId", IntegerType(), True),
                                       StructField("number", IntegerType(), True),
                                       StructField("position", IntegerType(), True),
                                       StructField("q1", StringType(), True),
                                       StructField("q2", StringType(), True),
                                       StructField("q3", StringType(), True),
                                       StructField("qualifyId", IntegerType(), True)])

# COMMAND ----------

qualifying_df = spark.read \
                    .schema(qualifying_schema) \
                    .option("multiLine","true") \
                    .json(f"{bronze_folder_path2}/qualifying")

# COMMAND ----------

display(qualifying_df.printSchema())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2 - Rename columns and add new columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit
qualifying_final_df = qualifying_df \
                          .withColumnsRenamed({"driverId": "driver_id", "raceId": "race_id", "constructorId": "constructor_id","qualifyId": "qualify_id"}) \
                          .withColumns({"ingestion_date" : current_timestamp(), "stage" : lit("silver")}) \
                          .withColumn("data_source", lit(v_data_source))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3 - Write output to parquet format

# COMMAND ----------

qualifying_final_df.write.mode("overwrite").format("parquet").saveAsTable("hive_metastore.f1_silver.qualifying")

# COMMAND ----------

dbutils.notebook.exit("OK")
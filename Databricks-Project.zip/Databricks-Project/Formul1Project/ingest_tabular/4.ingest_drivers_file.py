# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest Drivers.json file

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

dbutils.widgets.text(name="p_data_source", defaultValue="Ergest API")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text(name="p_data_source", defaultValue="Ergest API")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1 -  Read the JSON file using the spark dataframe reader API

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, DateType, IntegerType

# COMMAND ----------

name_schema = StructType(fields=[StructField("forename", StringType(), True),
                                 StructField("surname", StringType(), True)])

# COMMAND ----------

drivers_schema = StructType(fields=[StructField("code", StringType(), True),
                                    StructField("dob", DateType(), True),
                                    StructField("driverId", IntegerType(), True),
                                    StructField("driverRef", StringType(), True),
                                    StructField("name", name_schema, True),
                                    StructField("nationality", StringType(), True),
                                    StructField("number", IntegerType(), True),
                                    StructField("url", StringType(), True)])

# COMMAND ----------

drivers_df = spark.read.schema(drivers_schema).json(f"{bronze_folder_path2}/drivers.json")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2 - Rename columns and add new columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit, concat
drivers_with_columns_df = drivers_df \
                          .withColumnsRenamed({"driverId": "driver_id", "driverRef": "driver_ref"}) \
                          .withColumns({"ingestion_date" : current_timestamp(), "stage" : lit("silver")}) \
                          .withColumn("name", concat("name.forename", lit(" "), "name.surname")) \
                          .withColumn("data_source", lit(v_data_source))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3 - Drop Columns

# COMMAND ----------

drivers_final_df = drivers_with_columns_df.drop(drivers_with_columns_df["url"])

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 4 - Write output to parquet format

# COMMAND ----------

drivers_final_df.write.mode("overwrite").format("parquet").saveAsTable("hive_metastore.f1_silver.drivers")

# COMMAND ----------

dbutils.notebook.exit("OK")
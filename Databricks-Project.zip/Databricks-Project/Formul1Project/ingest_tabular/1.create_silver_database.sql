-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS hive_metastore.f1_silver
LOCATION "/mnt/formula1carracingdl/ingestfull/silver/"
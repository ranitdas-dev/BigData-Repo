# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest lap_times csv files

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

dbutils.widgets.text(name="p_data_source", defaultValue="Ergest API")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1 -  Read multiple CSV files using the spark dataframe reader API

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# COMMAND ----------

lap_times_schema = StructType(fields=[StructField("raceId", IntegerType(), True),
                                        StructField("driverId", IntegerType(), True),
                                        StructField("lap", IntegerType(), True),
                                        StructField("position", IntegerType(), True),
                                        StructField("time", StringType(), True),
                                        StructField("milliseconds", IntegerType(), True)])

# COMMAND ----------

lap_times_df = spark.read \
                .schema(lap_times_schema) \
                .csv(f"{bronze_folder_path2}/lap_times/")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2 - Rename columns and add new columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit
lap_times_final_df = lap_times_df \
                          .withColumnsRenamed({"driverId": "driver_id", "raceId": "race_id"}) \
                          .withColumns({"ingestion_date" : current_timestamp(), "stage" : lit("silver")}) \
                          .withColumn("data_source", lit(v_data_source))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3 - Write output to parquet format

# COMMAND ----------

lap_times_final_df.write.mode("overwrite").format("parquet").saveAsTable("hive_metastore.f1_silver.lap_times")

# COMMAND ----------

dbutils.notebook.exit("OK")
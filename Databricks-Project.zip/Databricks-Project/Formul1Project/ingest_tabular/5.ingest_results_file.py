# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest results.json file

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

dbutils.widgets.text(name="p_data_source", defaultValue="Ergest API")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1 - Read the JSON file using spark dataframe reader.

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, FloatType
results_schema = StructType(fields=[StructField("constructorId", IntegerType(), True),                 
                                    StructField("driverId", IntegerType(), True),
                                    StructField("fastestLap", IntegerType(), True),
                                    StructField("fastestLapSpeed", StringType(), True), 
                                    StructField("fastestLapTime", StringType(), True), 
                                    StructField("grid", IntegerType(), True), 
                                    StructField("laps", IntegerType(), True), 
                                    StructField("milliseconds", IntegerType(), True), 
                                    StructField("number", IntegerType(), True), 
                                    StructField("points", FloatType(), True), 
                                    StructField("position", IntegerType(), True), 
                                    StructField("positionOrder", IntegerType(), True), 
                                    StructField("positionText", StringType(), True), 
                                    StructField("raceId", IntegerType(), True), 
                                    StructField("rank", IntegerType(), True), 
                                    StructField("resultId", IntegerType(), False), 
                                    StructField("statusId", IntegerType(), True), 
                                    StructField("time", StringType(), True)])

# COMMAND ----------

results_df = spark.read \
                .schema(results_schema) \
                .format("json") \
                .load(f"{bronze_folder_path2}/results.json")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2 - Drop unwanted column from the dataframe

# COMMAND ----------

results_dropped_df = results_df.drop(results_df.statusId)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3 - Rename Column and Add ingestion_date to dataframe

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit
results_final_df = results_dropped_df \
                        .withColumnsRenamed({"resultId": "result_id", "constructorId": "constructor_id", "driverId": "driver_id", "fastestLap": "fastest_lap", "fastestLapSpeed": "fastest_lap_speed", "fastestLapTime": "fastest_lap_time","positionOrder": "position_order", "positionText": "position_text", "raceId": "race_id"}) \
                        .withColumn("ingestion_date", current_timestamp()) \
                        .withColumn("source", lit("silver")) \
                        .withColumn("data_source", lit(v_data_source))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 5 - Write data to parquet

# COMMAND ----------

results_final_df.write \
                .mode("overwrite") \
                .partitionBy("race_id") \
                .format("parquet") \
                .saveAsTable("hive_metastore.f1_silver.results")

# COMMAND ----------

dbutils.notebook.exit("OK")
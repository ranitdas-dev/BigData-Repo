-- Databricks notebook source
-- MAGIC %md
-- MAGIC #### Note
-- MAGIC -- You cannot use mount point in the path/location in the "create table using data source" for the catalogs in Unity Catalog enabled workspace except the catalog "hive_metastore".
-- MAGIC
-- MAGIC -- "hive_metastore" is to provide backwart compatibility

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS hive_metastore.f1_bronze;

-- COMMAND ----------

USE CATALOG hive_metastore

-- COMMAND ----------

USE f1_bronze;

-- COMMAND ----------

DROP TABLE IF EXISTS hive_metastore.f1_bronze.circuits;
CREATE TABLE IF NOT EXISTS hive_metastore.f1_bronze.circuits (
  circuitId INT,
  circuitRef STRING,
  name STRING,
  location STRING,
  country STRING,
  lat DOUBLE,
  lng DOUBLE,
  alt INT,
  url STRING
)
USING CSV
OPTIONS(path="/mnt/formula1carracingdl/ingestfull/bronze/circuits.csv", header=true)

-- COMMAND ----------

DROP TABLE IF EXISTS hive_metastore.f1_bronze.races;
CREATE TABLE IF NOT EXISTS hive_metastore.f1_bronze.races (
  raceId INT,
  year INT,
  round INT,
  circuitId INT,
  name STRING,
  date DATE,
  time STRING,
  url STRING
)
USING CSV
OPTIONS(path="/mnt/formula1carracingdl/ingestfull/bronze/races.csv", header=true)

-- COMMAND ----------

DROP TABLE IF EXISTS hive_metastore.f1_bronze.constructors;
CREATE TABLE IF NOT EXISTS hive_metastore.f1_bronze.constructors (
  constructorId INT,
  constructorRef STRING, 
  name STRING, 
  nationality STRING, 
  url STRING
)
USING JSON
OPTIONS(path="/mnt/formula1carracingdl/ingestfull/bronze/constructors.json")

-- COMMAND ----------

DROP TABLE IF EXISTS hive_metastore.f1_bronze.drivers;
CREATE TABLE IF NOT EXISTS hive_metastore.f1_bronze.drivers (
  code STRING,
  dob DATE,
  driverId INT,
  driverRef STRING,
  name STRUCT<forename: STRING, surname: STRING >,
  nationality STRING,
  number INT,
  url STRING
)
USING JSON
OPTIONS(path="/mnt/formula1carracingdl/ingestfull/bronze/drivers.json")

-- COMMAND ----------

DROP TABLE IF EXISTS f1_bronze.results;
CREATE TABLE IF NOT EXISTS f1_bronze.results (
 constructorId INT,
 driverId INT,
 fastestLap INT,
 fastestLapSpeed STRING,
 fastestLapTime STRING,
 grid INT,
 laps INT,
 milliseconds INT,
 number INT,
 points FLOAT,
 position INT,
 positionOrder INT,
 positionText STRING,
 raceId INT,
 rank INT,
 resultId INT,
 statusId INT,
 time STRING
)
USING JSON
OPTIONS(path="/mnt/formula1carracingdl/ingestfull/bronze/results.json")

-- COMMAND ----------

DROP TABLE IF EXISTS hive_metastore.f1_bronze.pit_stops;
CREATE TABLE IF NOT EXISTS hive_metastore.f1_bronze.pit_stops (
  driverId INT,
  duration STRING,
  lap INT,
  millseconds INT,
  raceId INT,
  stop INT,
  time STRING
)
USING JSON
OPTIONS(path="/mnt/formula1carracingdl/ingestfull/bronze/pit_stops.json", multiLine=true)

-- COMMAND ----------

DROP TABLE IF EXISTS hive_metastore.f1_bronze.lap_times;
CREATE TABLE IF NOT EXISTS hive_metastore.f1_bronze.lap_times (
  raceId INT,
  driverId INT,
  lap INT,
  position INT,
  time STRING,
  millseconds INT 
)
USING CSV
OPTIONS(path="/mnt/formula1carracingdl/ingestfull/bronze/lap_times/")

-- COMMAND ----------

DROP TABLE IF EXISTS hive_metastore.f1_bronze.qualifying;
CREATE TABLE IF NOT EXISTS hive_metastore.f1_bronze.qualifying (
  raceId INT,
  driverId INT,
  constructorId INT,
  number INT,
  position INT,
  q1 STRING,
  q2 STRING,
  q3 STRING,
  qualifyId INT
)
USING JSON
OPTIONS(path="/mnt/formula1carracingdl/ingestfull/bronze/qualifying/", multiline=true)

-- COMMAND ----------

DESC TABLE EXTENDED f1_bronze.circuits

-- COMMAND ----------

DROP TABLE IF EXISTS hive_metastore.f1_bronze.circuits;
CREATE TABLE IF NOT EXISTS hive_metastore.f1_bronze.circuits (
  circuitId INT,
  circuitRef STRING,
  name STRING,
  location STRING,
  country STRING,
  lat DOUBLE,
  lng DOUBLE,
  alt INT,
  url STRING
)
USING CSV
OPTIONS(header=true)

-- COMMAND ----------

select * from hive_metastore.f1_bronze.circuits
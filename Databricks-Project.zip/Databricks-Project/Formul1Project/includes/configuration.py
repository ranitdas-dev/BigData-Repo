# Databricks notebook source
bronze_folder_path = "/mnt/formula1carracingdl/bronze"
silver_folder_path = "/mnt/formula1carracingdl/silver"
gold_folder_path = "/mnt/formula1carracingdl/gold"

# COMMAND ----------

bronze_folder_path2 = "/mnt/formula1carracingdl/ingestfull/bronze"
silver_folder_path2 = "/mnt/formula1carracingdl/ingestfull/silver"
gold_folder_path2 = "/mnt/formula1carracingdl/ingestfull/gold"
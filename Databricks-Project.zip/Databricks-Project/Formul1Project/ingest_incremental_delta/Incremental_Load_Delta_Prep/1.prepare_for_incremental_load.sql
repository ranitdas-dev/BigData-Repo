-- Databricks notebook source
CREATE CATALOG IF NOT EXISTS formula1_catalog

-- COMMAND ----------

DROP DATABASE IF EXISTS formula1_catalog.f1_silver CASCADE;

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS formula1_catalog.f1_silver

-- COMMAND ----------

DROP DATABASE IF EXISTS formula1_catalog.f1_gold CASCADE;

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS formula1_catalog.f1_gold

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(dbutils.fs.mounts())
# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest qualifying json files

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text(name="p_data_source", defaultValue="Ergest API")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text(name="p_file_date", defaultValue="2021-03-21")
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1 -  Read multiple JSON files using the spark dataframe reader API

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# COMMAND ----------

qualifying_schema = StructType(fields=[StructField("raceId", IntegerType(), True),
                                       StructField("driverId", IntegerType(), True),
                                       StructField("constructorId", IntegerType(), True),
                                       StructField("number", IntegerType(), True),
                                       StructField("position", IntegerType(), True),
                                       StructField("q1", StringType(), True),
                                       StructField("q2", StringType(), True),
                                       StructField("q3", StringType(), True),
                                       StructField("qualifyId", IntegerType(), True)])

# COMMAND ----------

qualifying_df = spark.read \
                    .schema(qualifying_schema) \
                    .option("multiLine","true") \
                    .json(f"{bronze_folder_path}/{v_file_date}/qualifying")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2 - Rename columns and add new columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit
qualifying_final_df = qualifying_df \
                          .withColumnsRenamed({"driverId": "driver_id", "raceId": "race_id", "constructorId": "constructor_id","qualifyId": "qualify_id"}) \
                          .withColumns({"ingestion_date" : current_timestamp(), "stage" : lit("silver")}) \
                          .withColumn("data_source", lit(v_data_source)) \
                          .withColumn("file_date", lit(v_file_date))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3 - Write output to parquet format

# COMMAND ----------

merge_condition = "tgt.race_id = src.race_id AND tgt.qualify_id = src.qualify_id"
merge_delta_data(qualifying_final_df, "formula1_catalog", "f1_silver", "qualifying", "race_id", merge_condition)

# COMMAND ----------

dbutils.notebook.exit("OK")
# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest results.json file

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text(name="p_data_source", defaultValue="Ergest API")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text(name="p_file_date", defaultValue="2021-03-28")
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1 - Read the JSON file using spark dataframe reader.

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, FloatType
results_schema = StructType(fields=[StructField("constructorId", IntegerType(), True),                 
                                    StructField("driverId", IntegerType(), True),
                                    StructField("fastestLap", IntegerType(), True),
                                    StructField("fastestLapSpeed", StringType(), True), 
                                    StructField("fastestLapTime", StringType(), True), 
                                    StructField("grid", IntegerType(), True), 
                                    StructField("laps", IntegerType(), True), 
                                    StructField("milliseconds", IntegerType(), True), 
                                    StructField("number", IntegerType(), True), 
                                    StructField("points", FloatType(), True), 
                                    StructField("position", IntegerType(), True), 
                                    StructField("positionOrder", IntegerType(), True), 
                                    StructField("positionText", StringType(), True), 
                                    StructField("raceId", IntegerType(), True), 
                                    StructField("rank", IntegerType(), True), 
                                    StructField("resultId", IntegerType(), False), 
                                    StructField("statusId", IntegerType(), True), 
                                    StructField("time", StringType(), True)])

# COMMAND ----------

results_df = spark.read \
                .schema(results_schema) \
                .format("json") \
                .load(f"{bronze_folder_path}/{v_file_date}/results.json")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2 - Drop unwanted column from the dataframe

# COMMAND ----------

results_dropped_df = results_df.drop(results_df.statusId)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 4 - De-Duplicating dataframe

# COMMAND ----------

results_deduped_df = results_dropped_df.dropDuplicates(['raceId', 'driverId'])

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3 - Rename Column and Add ingestion_date to dataframe

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit
results_final_df = results_deduped_df \
                        .withColumnsRenamed({"resultId": "result_id", "constructorId": "constructor_id", "driverId": "driver_id", "fastestLap": "fastest_lap", "fastestLapSpeed": "fastest_lap_speed", "fastestLapTime": "fastest_lap_time","positionOrder": "position_order", "positionText": "position_text", "raceId": "race_id"}) \
                        .withColumn("ingestion_date", current_timestamp()) \
                        .withColumn("source", lit("silver")) \
                        .withColumn("data_source", lit(v_data_source)) \
                        .withColumn("file_date", lit(v_file_date))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 5 - Write data to parquet

# COMMAND ----------

# for race_id_list in results_final_df.select("race_id").distinct().collect():
#     if spark._jsparkSession.catalog().tableExists("f1_silver.results"):
#         spark.sql(f"ALTER TABLE f1_silver.results DROP IF EXISTS PARTITION (race_id = {race_id_list.race_id})")

# COMMAND ----------


merge_condition = "tgt.result_id = src.result_id AND tgt.race_id = src.race_id"
merge_delta_data(results_final_df, "formula1_catalog", "f1_silver", "results", "race_id", merge_condition)


# COMMAND ----------

dbutils.notebook.exit("OK")

# COMMAND ----------

# MAGIC %sql
# MAGIC select race_id, count(*) from formula1_catalog.f1_silver.results 
# MAGIC GROUP BY race_id
# MAGIC ORDER BY race_id DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC select race_id,driver_id, count(*) from formula1_catalog.f1_silver.results 
# MAGIC GROUP BY race_id,driver_id
# MAGIC having count(*) > 1
# MAGIC ORDER BY race_id,driver_id DESC
# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

races_df = spark.read.parquet(f"{silver_folder_path}/races").filter("race_year = 2019")
circuits_df = spark.read.parquet(f"{silver_folder_path}/circuits")

# COMMAND ----------

races_circuits_df = races_df.join(other=circuits_df, on=(races_df.circuit_id == circuits_df.circuit_id), how='inner').select(circuits_df.name, circuits_df.location, circuits_df.race_country,races_df.round, races_df.name).display()

# COMMAND ----------



# COMMAND ----------

display(races_df)

# COMMAND ----------

# races_filtered_df = races_df.filter((races_df.race_year == 2019) & (races_df.race_year == 2018)).display()
races_filtered_df = races_df.where("""race_year = YEAR(DATEADD(YEAR, -6, GETDATE()))""").display()


# COMMAND ----------


# Databricks notebook source
display(dbutils.fs.mounts())

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1carracingdl/demo"))

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS f1_demo
# MAGIC LOCATION '/mnt/formula1carracingdl/demo'

# COMMAND ----------

results_df = spark.read.option("inferSchema", "true").json("/mnt/formula1carracingdl/bronze/2021-03-28/results.json")

# COMMAND ----------

results_df.write.format("delta").mode("overwrite").saveAsTable("f1_demo.results_managed")

# COMMAND ----------

results_df.write.format("delta").mode("overwrite").save("/mnt/formula1carracingdl/demo/results_external")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demo.results_external

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE f1_demo.results_external
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/formula1carracingdl/demo/results_external"

# COMMAND ----------

results_df.write.format("delta").mode("overwrite").partitionBy("constructorId").saveAsTable("f1_demo.results_managed_partitioned")

# COMMAND ----------

# %sql
# update f1_demo.results_managed
# SET points = 11 - position
# WHERE position <=10
from delta.tables import *
deltaTable = DeltaTable.forPath(spark, "/mnt/formula1carracingdl/demo/results_managed")

deltaTable.update(condition="position <= 10", set={"points": "11 - position"})
 

# COMMAND ----------

deltaTable.delete("points=0")

# COMMAND ----------

MERGE INTO 

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demo.results_managed

# COMMAND ----------

drivers_df_Day1 = spark.read.option("inferSchema", "true") \
            .json("/mnt/formula1carracingdl/bronze/2021-03-28/drivers.json") \
            .filter("driverId <=10")

# COMMAND ----------

drivers_df_Day2 = spark.read.option("inferSchema", "true") \
            .json("/mnt/formula1carracingdl/bronze/2021-03-28/drivers.json") \
            .filter("driverId BETWEEN 6 AND 15")

# COMMAND ----------

drivers_df_Day3 = spark.read.option("inferSchema", "true") \
            .json("/mnt/formula1carracingdl/bronze/2021-03-28/drivers.json") \
            .filter("driverId BETWEEN 6 AND 15 OR driverId BETWEEN 6 AND 15")

# COMMAND ----------

display(drivers_df_Day3)

# COMMAND ----------

drivers_df_Day2.createOrReplaceTempView("drivers_df_Day2")
drivers_df_Day1.createOrReplaceTempView("drivers_df_Day1")


# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_demo.drivers_managed
# MAGIC USING DELTA
# MAGIC AS SELECT * FROM drivers_df_Day1 WHERE 1=0

# COMMAND ----------

deltaTable = DeltaTable.forPath(spark, "/mnt/formula1carracingdl/demo/drivers_external")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_demo.drivers_managed

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_demo.drivers_managed tgt
# MAGIC USING drivers_df_Day1 src
# MAGIC ON tgt.driverId = src.driverId
# MAGIC WHEN MATCHED 
# MAGIC THEN UPDATE
# MAGIC SET tgt.dob = src.dob
# MAGIC     ,tgt.name = src.name
# MAGIC WHEN NOT MATCHED THEN
# MAGIC INSERT *

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_demo.drivers_managed tgt
# MAGIC USING drivers_df_Day2 src
# MAGIC ON tgt.driverId = src.driverId
# MAGIC WHEN MATCHED 
# MAGIC THEN UPDATE
# MAGIC SET tgt.dob = src.dob
# MAGIC     ,tgt.name = src.name
# MAGIC WHEN NOT MATCHED THEN
# MAGIC INSERT *

# COMMAND ----------

from delta.tables import *

drivers_managed_df = DeltaTable.forPath(spark, "/mnt/formula1carracingdl/demo/drivers_managed")



# COMMAND ----------

drivers_managed_df.alias("tgt") \
    .merge(drivers_df_Day3.alias("src"), "tgt.driverId = src.driverId") \
    .whenMatchedUpdate(set={"tgt.name": "src.name", "tgt.dob" : "src.dob"}) \
    .whenNotMatchedInsertAll().execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY  f1_demo.drivers_managed

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demo.drivers_managed TIMESTAMP AS OF '2025-03-08T12:48:31.000+00:00'

# COMMAND ----------

# MAGIC %sql
# MAGIC SET spark.databricks.delta.retentionDurationCheck.enabled = false;

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM f1_demo.drivers_managed RETAIN 0 HOURS
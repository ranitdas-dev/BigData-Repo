# Databricks notebook source
# MAGIC %md
# MAGIC #### Access dataframes using SQL

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

race_results_df = spark.read.parquet(f"{gold_folder_path}/race_results")

# COMMAND ----------

race_results_df.createOrReplaceTempView("v_race_results")

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(1) as race_results_count
# MAGIC from v_race_results
# MAGIC where race_year = 2020

# COMMAND ----------

race_results_2019_df = spark.sql("select * from v_race_results where race_year = 2019")

# COMMAND ----------

display(race_results_2019_df)

# COMMAND ----------

race_results_df.createOrReplaceGlobalTempView("gv_race_results")

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(1) as race_results_count
# MAGIC from global_temp.gv_race_results
# MAGIC where race_year = 2020

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TABLES IN GLOBAL_TEMP

# COMMAND ----------


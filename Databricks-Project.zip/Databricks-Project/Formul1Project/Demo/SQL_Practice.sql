-- Databricks notebook source
SHOW DATABASES

-- COMMAND ----------

USE f1_silver

-- COMMAND ----------

SHOW TABLES IN f1_silver

-- COMMAND ----------

DESCRIBE EXTENDED drivers 

-- COMMAND ----------

select * from f1_silver.drivers 
--where nationality = 'British'
--Mexican
--Argentine

-- COMMAND ----------

DROP TABLE IF EXISTS f1_bronze.demo_table1;
CREATE TABLE f1_bronze.demo_table1(
Demo_Id INT NOT NULL,
Demo_Date INTERVAL DAY TO HOUR,
Demo_Array array<string>,
Demo_Map map<string, INT>
)
USING DELTA

-- COMMAND ----------

select * from f1_bronze.demo_table1 

-- COMMAND ----------

INSERT INTO f1_bronze.demo_table1 
VALUES (1, INTERVAL '10 22:30:15.200000' DAY TO SECOND, ARRAY('val1', 'val2', 'val3'), MAP('key1', 1, 'key2', 2, 'key3', 3, 'key4', 4)),
(2, INTERVAL '22:30:15.200000' HOUR TO SECOND, ARRAY('val4', 'val5', 'val6'), MAP('key5', 5, 'key6', 6, 'key7',7, 'key8', 8))

-- COMMAND ----------

INSERT INTO f1_bronze.demo_table1 
VALUES (1, CURRENT_TIMESTAMP(), ARRAY('val1', 'val2', 'val3'), MAP('key1', 1, 'key2', 2, 'key3', 3, 'key4', 4)),
(2, CURRENT_TIMESTAMP(), ARRAY('val4', 'val5', 'val6'), MAP('key5', 5, 'key6', 6, 'key7',7, 'key8', 8))

-- COMMAND ----------

select 
Demo_Date + INTERVAL '1-2' YEAR TO MONTH, INTERVAL '1-2' YEAR TO MONTH
, Demo_Date + INTERVAL '10 22:30:15.200000' DAY TO SECOND, INTERVAL '10 22:30:15.200000' DAY TO SECOND
 from f1_bronze.demo_table1 

-- COMMAND ----------

SELECT array_contains(Demo_Array, 'val2') from f1_bronze.demo_table1 

-- COMMAND ----------

INSERT INTO f1_bronze.demo_table1 
VALUES (1, INTERVAL '1-2' YEAR TO MONTH, ARRAY('val1', 'val2', 'val3'), MAP('key1', 1, 'key2', 2, 'key3', 3, 'key4', 4)),
(2, INTERVAL '10 22:30:15.200000' DAY TO SECOND, ARRAY('val4', 'val5', 'val6'), MAP('key5', 5, 'key6', 6, 'key7',7, 'key8', 8))
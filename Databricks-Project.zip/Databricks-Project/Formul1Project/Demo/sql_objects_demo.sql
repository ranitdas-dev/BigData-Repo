-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS DEMO
COMMENT "This database is for demo and practice purpose"
WITH DBPROPERTIES ("Creator"="Ranit", "Date_Of_Creation" = "2025-02-15")



-- COMMAND ----------

DESC SCHEMA EXTENDED DEMO

-- COMMAND ----------

SHOW DATABASES;

use demo

-- COMMAND ----------

SELECT current_database();

-- COMMAND ----------

-- MAGIC %run "../includes/configuration"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df = spark.read.parquet(f"{gold_folder_path}/race_results")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.mode("overwrite").format("parquet").saveAsTable("race_results")

-- COMMAND ----------

DESCRIBE TABLE EXTENDED race_results

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").option("path", f"{gold_folder_path}/race_results_ext_pyt").saveAsTable("demo.race_results_ext_pyt")

-- COMMAND ----------

DESCRIBE TABLE EXTENDED race_results_ext_pyt

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.printSchema().dispaly()

-- COMMAND ----------

drop table race_results_ext_sql

-- COMMAND ----------

CREATE TABLE race_results_ext_sql(
race_year string,
race_date string,
race_name string,
circuit_location string,
driver_name string,
driver_number string,
driver_nationality string,
team string,
grid string,
fastest_lap string,
race_time string,
points string,
position string,
ingestion_date string,
stage string
)
USING PARQUET
PARTITIONED BY (race_year)
CLUSTERED BY (team) SORTED BY (race_date) INTO 2 BUCKETS
COMMENT "This table is for demo and practice purpose"
TBLPROPERTIES ("Creator"="Ranit")
LOCATION "/mnt/formula1carracingdl/gold/race_results_ext_sql"

-- COMMAND ----------

DESCRIBE TABLE EXTENDED race_results_ext_sql

-- COMMAND ----------

INSERT INTO race_results_ext_sql
SELECT * FROM race_results

-- COMMAND ----------

update race_results
set stage = 'silver'


-- COMMAND ----------

SELECT distinct stage FROM race_results_ext_sql

-- COMMAND ----------

SHOW TABLES IN DEMO

-- COMMAND ----------

DROP TABLE IF EXISTS race_results

-- COMMAND ----------


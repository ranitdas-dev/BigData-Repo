# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

race_results_df = spark.read.parquet(f"{gold_folder_path}/race_results").where("race_year in (2019, 2020)")

# COMMAND ----------

display(race_results_df)

# COMMAND ----------

from pyspark.sql.functions import count,count_distinct, sum

race_results_df.select(count("*").alias("record_count")).show()


# COMMAND ----------

race_results_df2 = race_results_df.groupBy("driver_name", race_results_df.race_year).agg(sum(race_results_df.points).alias("total_points"), count("*").alias("race_count")).orderBy(["total_points",  race_results_df.race_year], ascending=[False, False])
# race_results_df.groupBy("driver_name").agg({"points" : "sum", "*" : "count"}).withColumnRenamed("sum(points)", "total_points").show()

# COMMAND ----------

from pyspark.sql.window import Window
window = Window.partitionBy("race_year").orderBy(race_results_df2.total_points.desc())

# COMMAND ----------

from pyspark.sql.functions import row_number, rank
race_results_df2.withColumn("rank", rank().over(window)).show()
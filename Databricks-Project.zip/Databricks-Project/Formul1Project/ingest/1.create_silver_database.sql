-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_silver
LOCATION "/mnt/formula1caracingdl/silver"

-- COMMAND ----------

describe schema extended f1_silver;
describe schema extended f1_bronze
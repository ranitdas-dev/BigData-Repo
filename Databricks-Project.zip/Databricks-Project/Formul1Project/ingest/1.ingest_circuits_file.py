# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest circuits.csv file

# COMMAND ----------

dbutils.widgets.text(name="p_data_source", defaultValue="Ergest API")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

#Go back one step from ingest folder then get into includes folder and run configuration script

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1: Read the CSV file using spark dataframe reader.

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType
circuits_schema = StructType(fields=[StructField("circuitId", IntegerType(), False),
                                     StructField("circuitRef", StringType(), True),
                                     StructField("name", StringType(), True),
                                     StructField("location", StringType(), True),
                                     StructField("country", StringType(), True),
                                     StructField("lat", DoubleType(), True),
                                     StructField("lng", DoubleType(), True),
                                     StructField("alt", IntegerType(), True),
                                     StructField("url", StringType(), True)])

# COMMAND ----------

circuits_df = spark.read \
.option('header', True) \
.schema(circuits_schema) \
.csv(path=f'{bronze_folder_path2}/circuits.csv')

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2 - Select only the required columns

# COMMAND ----------

#Not let you change the name of the column with in the select statement as string is used to define the columns
circuits_selected_df = circuits_df.select('circuitId', 'circuitRef', 'name', 'location', 'country', 'lat', 'lng', 'alt')

#Let you change the name of the column with in the select statement as column type is use to define the columns
# circuits_selected_df = circuits_df.select(circuits_df.circuitId, circuits_df.circuitRef, circuits_df.name, 
#                                           circuits_df.location, circuits_df.country, circuits_df.lat, circuits_df.lng, circuits_df.alt)

# circuits_selected_df = circuits_df.select(circuits_df["circuitId"], circuits_df["circuitRef"], circuits_df["name"], 
#                                           circuits_df["location"], circuits_df["country"], circuits_df["lat"], circuits_df["lng"], circuits_df["alt"])

#circuits_selected_df = circuits_df.select(circuits_df[0], circuits_df[1], circuits_df[2],circuits_df[3], circuits_df[4]
#                                         , circuits_df[5], circuits_df[6], circuits_df[7])

from pyspark.sql.functions import col
circuits_selected_df = circuits_df.select(col('circuitId'), col('circuitRef'), col('name'), col('location')
                                          , col('country').alias('race_country'), col('lat'), col('lng'), col('alt'))


# COMMAND ----------

# MAGIC %md
# MAGIC #### Step- 3: Rename the columns as required

# COMMAND ----------

from pyspark.sql.functions import lit
circuits_renamed_df = circuits_selected_df \
.withColumnRenamed("circuitId", "circuit_id") \
.withColumnRenamed("circuitRef", "circuit_ref") \
.withColumnsRenamed({"lat" : "lattitude", "lng" : "longitude", "alt": "altitude"}) \
.withColumn("data_source", lit(v_data_source))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 4 - Add ingestion_date and stage Column

# COMMAND ----------

circuits_final_df = add_ingestion_date_and_stage(circuits_renamed_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 5 - Write data to parquet

# COMMAND ----------

circuits_final_df.write.mode("overwrite").parquet(f"{silver_folder_path2}/circuits")

# COMMAND ----------

dbutils.notebook.exit("OK")

# COMMAND ----------

spark.read.parquet(f"{silver_folder_path2}/circuits").display()
# Databricks notebook source
v_result = dbutils.notebook.run(path="1.ingest_circuits_file", timeout_seconds=0, arguments={"p_data_source" : "Ergast API"})

# COMMAND ----------

print(v_result)

# COMMAND ----------

v_result = dbutils.notebook.run(path="2.ingest_races_file", timeout_seconds=0, arguments={"p_data_source" : "Ergast API"})
print(v_result)

# COMMAND ----------

v_result = dbutils.notebook.run(path="3.ingest_constructors_file", timeout_seconds=0, arguments={"p_data_source" : "Ergast API"})
print(v_result)

# COMMAND ----------

v_result = dbutils.notebook.run(path="4.ingest_drivers_file", timeout_seconds=0, arguments={"p_data_source" : "Ergast API"})
print(v_result)

# COMMAND ----------

v_result = dbutils.notebook.run(path="5.ingest_results_file", timeout_seconds=0, arguments={"p_data_source" : "Ergast API"})
print(v_result)

# COMMAND ----------

v_result = dbutils.notebook.run(path="6.ingest_pit_stops_file", timeout_seconds=0, arguments={"p_data_source" : "Ergast API"})
print(v_result)

# COMMAND ----------

v_result = dbutils.notebook.run(path="7.ingest_lap_times_file", timeout_seconds=0, arguments={"p_data_source" : "Ergast API"})
print(v_result)

# COMMAND ----------

v_result = dbutils.notebook.run(path="8.ingest_qualifying_file", timeout_seconds=0, arguments={"p_data_source" : "Ergast API"})
print(v_result)
# Databricks notebook source
dbutils.widgets.text(name="p_data_source", defaultValue="Eargest API")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

# MAGIC %run "../includes/configuration" 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1: Read the CSV file using spark dataframe reader.

# COMMAND ----------

# DBTITLE 1,Define Schema for races_df
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType
races_schema = StructType(fields=[StructField("raceId", IntegerType(), False),
                                   StructField("year", IntegerType(), True),
                                   StructField("round", IntegerType(), True),
                                   StructField("circuitId", IntegerType(), True),
                                   StructField("name", StringType(), True),
                                   StructField("date", DateType(), True),
                                   StructField("time", StringType(), True),
                                   StructField("url", StringType(), True)])

# COMMAND ----------

races_df = spark.read \
        .options(header="true") \
        .schema(races_schema) \
        .csv(f"{bronze_folder_path2}/races.csv")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2 - Select only the required columns

# COMMAND ----------

races_selected_df = races_df.select(races_df.columns[:7])

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step- 3: Rename the columns as required

# COMMAND ----------

races_renamed_df = races_selected_df \
                    .withColumnsRenamed({"raceId" : "race_id", "year" : "race_year", "circuitId": "circuit_id"})

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 4 - Add ingestion_date and stage Column. Merge date and time to make timestamp column

# COMMAND ----------

from pyspark.sql.functions import col, concat_ws, to_timestamp, current_timestamp, lit
races_final_df = races_renamed_df \
                    .withColumn("race_timestamp", to_timestamp(concat_ws(" ", col("date"), "time"), "yyyy-MM-dd HH:mm:ss")) \
                    .withColumns({"ingestion_date" : current_timestamp(), "stage" : lit("silver")}) \
                    .withColumn("data_source", lit(v_data_source))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 5 - Write data to parquet

# COMMAND ----------

races_final_df.write.mode("overwrite").partitionBy("race_year").format("parquet").save("/mnt/formula1carracingdl/ingestfull/silver/races")

# COMMAND ----------

dbutils.notebook.exit("OK")
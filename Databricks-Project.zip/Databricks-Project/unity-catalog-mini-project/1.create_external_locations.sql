-- Databricks notebook source
CREATE EXTERNAL LOCATION IF NOT EXISTS databricksprojucextdl_bronze
URL 'abfss://bronze@databricksprojucextdl.dfs.core.windows.net/'
WITH (STORAGE CREDENTIAL `databricks-proj-uc-ext-access`)

-- COMMAND ----------

desc EXTERNAL LOCATION databricksprojucextdl_bronze

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(dbutils.fs.ls('abfss://bronze@databricksprojucextdl.dfs.core.windows.net/'))

-- COMMAND ----------

CREATE EXTERNAL LOCATION IF NOT EXISTS databricksprojucextdl_silver
URL 'abfss://silver@databricksprojucextdl.dfs.core.windows.net/'
WITH (STORAGE CREDENTIAL `databricks-proj-uc-ext-access`)

-- COMMAND ----------

CREATE EXTERNAL LOCATION IF NOT EXISTS databricksprojucextdl_gold
URL 'abfss://gold@databricksprojucextdl.dfs.core.windows.net/'
WITH (STORAGE CREDENTIAL `databricks-proj-uc-ext-access`)

-- COMMAND ----------

